import java.util.*;






public class RandomArray {
	public static int[] fillRandomValues(int argSize) {
	
		int[] randoArray = new int[argSize];
		Random randomNumbers= new Random();
		
		for(int i =0; i<randoArray.length; ++i) {
		
		int r = randomNumbers.nextInt(60) -30; //gives a number between -30 and 60
		
		randoArray[i] = r;
		
		//System.out.println(randoArray[i]);
		}
	return randoArray;
		
	}

	public static fillRandomValues()	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int[] randoArray = new int[100];
	//	for(int i =0; i<randoArray.length; ++i) {
		//Random randomNumbers= new Random();
	//int r = randomNumbers.nextInt(100) -50; //gives a number between -50 and 50
		//randoArray[i] = r;
		
		//System.out.println(randoArray[i]);
		
		int[] randomValues = fillRandomValues(50);
		int[] onlyPositives = new int[randomValues.length];
		int howManyPositives= getPositive(randomValues,onlyPositives);

		for(int i=0; i<random.Values.length; i++){
		    System.out.println(randomvalues[i]);
		    
		} 
	
			
	}
		
		
				
}


