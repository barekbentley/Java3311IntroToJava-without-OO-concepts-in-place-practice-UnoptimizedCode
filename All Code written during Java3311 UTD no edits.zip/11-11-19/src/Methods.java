import java.util.*;


	





public class Methods {
	
	public static boolean checkPresence(int[] arrayToBeSearched, int searchElement) {

		for(int i =0; i<arrayToBeSearched.length; i++ ) {
			if(arrayToBeSearched[i]==searchElement) {
				return true;
			}
		}
			return false;
		}

	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] randomValues = new int[10];
		
		Random randomNumbers = new Random();
		for(int i=0; i<10; i++) {
			int r = randomNumbers.nextInt(100)-50;
			System.out.println(randomValues[i]);
		}
			
		if(checkPresence(randomValues,7))
			System.out.println("Found 7");
		else
			System.out.print("7 not found");
	}

}
