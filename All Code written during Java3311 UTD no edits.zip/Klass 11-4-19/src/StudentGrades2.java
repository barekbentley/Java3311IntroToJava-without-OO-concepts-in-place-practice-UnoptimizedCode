import java.util.*;

public static String compute_letter_grade( double argWeightedTotal) {

String[] letterGrades = {"A+","A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"};
int[] limits = {97,94,90,87,84,80,77,74,70,67,64,60,0};

for(int i =0; i< )

return argWeightedTotal;
}

//public static String print_output(String name,String grade){

//return;

//}

public class StudentGrades2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scnr = new Scanner(System.in);
		
		String[] names = {"Abe", "Bobbi", "Charlie", "Daisy", "Eric"};
		double[] grades = new double[names.length];
		
		for(int i =0; i<names.length; i++) {
		System.out.println("Enter the grade for student:"+ names[i]);
		grades[i]= scnr.nextDouble();
		//System.out.println(grades[i]);
		}
	
	}
}



