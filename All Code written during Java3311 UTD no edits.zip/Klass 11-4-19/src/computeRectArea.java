import java.util.*;

public class computeRectArea {

	public static double computeRectArea1(double length, double width) {
		double area = length * width;
		return area;
	}

	public static double computeRectPerimeter(double length, double width) {
		double perimeter = 2 * (length + width);
		return perimeter;
	}

	public static double computeCircleArea(double radius) {
		final double PIE = 3.14159;
		double area = PIE * radius * radius;

		return area;
	}

	public static double computeCircleCircumference(double radius) {
		final double PIE = 3.14159;
		double circumference = PIE * 2 * radius;

		return circumference;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		System.out.println("Enter length: ");
		double len = scnr.nextDouble();

		System.out.println("Enter the width: ");
		double wid = scnr.nextDouble();

		double area = computeRectArea1(len, wid);
		System.out.println("Area is: " + area);

		double perimeter = computeRectPerimeter(50, 20);

		System.out.println("Perimeter is: " + perimeter);

		double areaCircle = computeCircleArea(200);

		System.out.println(areaCircle);

		double circleCircum = computeCircleCircumference(500);

		System.out.println(circleCircum);

	}

}
