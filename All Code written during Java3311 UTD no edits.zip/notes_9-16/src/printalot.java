import java.util.*;
public class printalot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int counter = 0;
		int lineNumber = 1;
		
		while (counter <100) {
			System.out.println("Welcome to Java!" + lineNumber);
			 counter++;
			lineNumber = lineNumber+1;
		}

	}

}
