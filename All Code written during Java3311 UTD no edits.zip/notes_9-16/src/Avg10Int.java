import java.util.*;
public class Avg10Int {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		double avg;
		int counter = 0;
		int grade = 0;
		int total =0;
		while (counter<10) {
			System.out.println("Enter your grade");
			grade = scnr.nextInt();
			total = total +grade;
			counter++;
			
		}
		avg = total/10;
		System.out.println("Your average grade is " + avg);
	}

}
