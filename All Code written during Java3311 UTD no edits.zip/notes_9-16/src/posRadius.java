import java.util.*;
public class posRadius {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		int radius=0;
		double PI = 3.14;
		System.out.println("What is the radius?");
		
		radius = scnr.nextInt();
		
		while (radius<0) {
			System.out.println("Enter a positive Radius");
			radius = scnr.nextInt();
		}
		double area = 3.14 * radius *radius;
		System.out.println(area);
		
	}

}
