import java.util.*;
public class doWhileCircleBetter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		int num1, num2;
		
		int sum=0;
		String promtResponse;
		
		do { 
			System.out.println("Enter first number to be added : ");
			num1 = scnr.nextInt();
			System.out.println("Enter second number to be added");
			num2 = scnr.nextInt();
			
			sum = num1+num2;
			System.out.println("Result = : "+ sum);
			System.out.println("Do you want to continue?");
			scnr.nextLine(); //crucial to loop and input flush
			promtResponse =scnr.nextLine();
		
	}while(promtResponse.equalsIgnoreCase("YES"));
	}
}

