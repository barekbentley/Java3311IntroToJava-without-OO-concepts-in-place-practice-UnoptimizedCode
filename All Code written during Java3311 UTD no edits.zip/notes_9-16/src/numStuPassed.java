import java.util.*;
public class numStuPassed {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("How many students are in the class?");
		int numStudents = scnr.nextInt();
		int counter = 0;
		int PASSING = 60;
		int numPassing = 0;
		int grade = 0;
		while(counter < numStudents) {
			System.out.print("What is the grade?");
			grade = scnr.nextInt();
			if(grade >= PASSING) {
				numPassing++;
			}
			counter++;
		}
		System.out.println("The number of passing students is "+numPassing);
		
		
	}

}
