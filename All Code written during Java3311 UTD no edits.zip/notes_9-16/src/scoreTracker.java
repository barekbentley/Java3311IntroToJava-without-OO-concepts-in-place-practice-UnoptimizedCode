import java.util.*;
public class scoreTracker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		int userInput =0;
		int totalScore= 1;
		int numGames= -1;
		System.out.println("Enter -1 to quit entering scores");
		
		while(userInput != -1) {
			System.out.println("What is the score of the game?");
			userInput = scnr.nextInt();
			totalScore = userInput + totalScore;
			numGames++;
		}
		//totalScore = totalScore +1; //bug fix
		//numGames = numGames -1; //bug fix
		System.out.println("Number of Games played "+numGames+" Total score is "+totalScore);
	}

}
