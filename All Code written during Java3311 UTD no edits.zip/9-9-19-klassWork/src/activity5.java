import java.util.*;
public class activity5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scnr = new Scanner(System.in);
		String ui = "0";
		String password = "1234";
		System.out.println("What is your password?");
		
		ui += scnr.next();
			
			if (ui == password) {
		
		
	}

}
