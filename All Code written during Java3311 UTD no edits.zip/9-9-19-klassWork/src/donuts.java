import java.util.*;
public class donuts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		int numDonuts;
		int num Boxes;
		System.out.println("What is the number of donuts?");
		
		numDonuts = scnr.nextInt();
		
		num
		if (numDonuts <= 12) {
		System.out.println("You need one box");
		}
		else if (numDonuts/12) {
			
		}
		
	}

	}
