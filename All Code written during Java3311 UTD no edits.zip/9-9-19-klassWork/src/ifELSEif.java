import java.util.*;
public class ifELSEif {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		double weight;
		double height;
		double bmi;
		System.out.println("What is your weight?");
		weight = scnr.nextInt();
		
		System.out.println("What is your height?");
		height = scnr.nextInt();
		
		bmi = weight*703 /(height*height);
		
		if (bmi >= 25 ) {
			System.out.println("OVERWEIGHT");
		}
			else if (bmi < 18.5) {
				System.out.println("UNDERWEIGHT");
			}
			else { 
				System.out.println("NORMAL");
				}
		System.out.println(bmi);
			}
		
	}


