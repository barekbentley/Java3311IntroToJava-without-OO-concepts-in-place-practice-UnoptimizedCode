import java.util.*;
public class testAvg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int test1Mark;
		int test2Mark;
		int test3Mark;
		
		double totalScore = 0;
		
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("What is your first testscore?");
		test1Mark = scnr.nextInt();
		System.out.println("What is your second testscore?");
		test2Mark = scnr.nextInt();
		System.out.println("What is your third testscore?");
		test3Mark = scnr.nextInt();
		// System.out.println("what is your first score");
		//totalSCore += scnr.nextInt(); etc.... instead of 3 variables
		//
		//
		//
		//
		double average = ((test1Mark+test2Mark+test3Mark)/3);
	
					if (average >=95) {
						System.out.println("Great Job!");
					}

	}
}
