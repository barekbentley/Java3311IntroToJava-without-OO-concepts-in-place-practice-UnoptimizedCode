import java.util.*;
public class activity4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	int testINT = 0;
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("What is your integer?");
		testINT += scnr.nextInt();
		
		if ((testINT % 2) ==0 ) {
			System.out.println("Your integer is even");
		} else {
			System.out.print("Your integer is odd");
		}
		}
	}


