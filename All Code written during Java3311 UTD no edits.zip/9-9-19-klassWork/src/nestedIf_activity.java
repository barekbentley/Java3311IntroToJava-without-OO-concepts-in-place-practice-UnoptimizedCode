import java.util.*;
public class nestedIf_activity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		
		
		
		
		
	}

}
