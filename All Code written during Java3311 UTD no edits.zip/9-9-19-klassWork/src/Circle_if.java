import java.util.*; // allows me to import the scanner
public class Circle_if {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double radius; //step one, (stores radius).
		double area; // stores area value
		double PI = 3.14;
		double perimeter;
		
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Please enter the radius value"); //Prompt
		
		radius = scnr.nextDouble(); //takes user input for radius value and stores it as radius
		//System.out.println(radius);
		
		
									if (radius > 0) { 
										area = PI*radius*radius;
										perimeter = 2*PI*radius;
										
										System.out.println("Area is: "+area+"Perimeter is: "+ perimeter);
										
			
										} else {
										System.out.println("Radius cannot be negtaive");
										}
		
		
	}

}
