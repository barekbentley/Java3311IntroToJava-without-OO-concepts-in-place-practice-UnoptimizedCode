import java.util.Scanner;
public class Weir {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		int userNum = 5;
		int i; //i
		int j; //j
		
		for (i=0; i<=5; i++) {
			System.out.print(" ");
			
			for (j=0; j<=5; j++) {
				System.out.println(i);
			}
			}
		}
	}
		
