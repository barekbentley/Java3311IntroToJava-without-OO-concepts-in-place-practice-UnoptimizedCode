package weirdSpacing;

public class WEERD_Spacing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
