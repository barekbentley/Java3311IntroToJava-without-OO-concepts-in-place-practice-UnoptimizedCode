import java.util.*;

public class LettersAndGrades {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Write code to accept weighted total grade into the appropriate location for
		// each student found in the array names.
		// Array grades has been created for you for this purpose.
		// Compute the letter grade to be assigned for each student based on the limits
		// given in the limits array.

		int j=0; // for searching through limits arrays
		Scanner scnr = new Scanner(System.in);

		String[] letterGrades = { "A+", "A", "A-",

				"B+", "B", "B-",

				"C+", "C", "C-",

				"D+", "D", "D-",

				"F" };

		int[] limits = { 97, 94, 90,

				87, 84, 80,

				77, 74, 70,

				67, 64, 60,

				0

		};

		String[] names = { "Abe", "Bobbi", "Charlie", "Daisy", "Eric" };

		double[] grades = new double[names.length];
		//double[] grades = {-1,-1,-1,-1,-1};
		for (int i = 0; i < names.length; ++i) {
			// prompt
			//do {
			System.out.println("Enter a grade for: " + names[i]);
			//if(scnr.hasNextInt()) {
			grades[i] = scnr.nextDouble();
			}
			//else if(scnr.hasNext(char)) {
				//break;
	
				
			//}while(grades[i]<0);
		
		// System.out.println(grades[0]+" "+grades[1]+" "+grades[2]+" "+grades[3]+"
		// "+grades[4]);

		for (int i = 0; i < names.length; ++i) { // check every person and grade

			for (j=0; grades[i]<limits[j]; ++j); { // compare the index value of grade to the index j of limit
				
				

			}
			System.out.println("The letter grade for "+names[i]+": " +letterGrades[j]);
		}

	}

}
