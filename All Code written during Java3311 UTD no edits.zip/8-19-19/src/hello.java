
public class hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Problem Statement :
John worked 40 hours this week. His salary is $50/hour.
Calculate the John�s salary for this week.
Print the salary*/
		
		int hoursWorked = 40;
		double payPerHour = 50;
		double salary = hoursWorked * payPerHour;
		System.out.println(salary);


		
	}

}
