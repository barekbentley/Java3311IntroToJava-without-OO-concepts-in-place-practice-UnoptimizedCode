import java.util.*;
public class highway {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		int highwayNum = 0;
		int hwRemainder;
		
		System.out.println("Enter the highway number?");
		highwayNum = scnr.nextInt();
		
		if (highwayNum <= 0 || highwayNum >= 1000) {
			System.out.println(highwayNum+" is not a valid highway number");
			
		}
		else if ( highwayNum >= 100 && highwayNum <=999) {
			//System.out.println("Auxilary highway");
		}
			
			
	}
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*System.out.println("Enter the highway number?");
		highwayNum = scnr.nextInt();
		if(highwayNum <= 0 || highwayNum >= 1000) {
			System.out.println(highwayNum+" is not a valid highway number.");
		}
		else if( highwayNum < 100) {
			if(highwayNum%2 ==0) {
				System.out.println(highwayNum+" is primary going east/west");
			}
			else if(highwayNum%2 != 2) {
				System.out.println(highwayNum+" is primary going north/south");
				
			}
			if(highwayNum >= 100 ) {
				System.out.println("above 100");
				
			}
		}
			
		}
		}
		//else if (highway)
	*/


