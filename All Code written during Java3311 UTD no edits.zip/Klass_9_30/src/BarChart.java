import java.util.*;

public class BarChart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		int storeOne;
		int storeTwo;
		int storeThree;
		int storeFour;
		int storeFive;
		
		System.out.println("Wnat are the sales for store One?");
		
		storeOne = scnr.nextInt();
		
		System.out.println("Wnat are the sales for store Two?");
		
		storeTwo = scnr.nextInt();
		
		System.out.println("Wnat are the sales for store Three?");
		
		storeThree = scnr.nextInt();
		
		System.out.println("Wnat are the sales for store Four?");

		storeFour = scnr.nextInt();
		
		System.out.println("Wnat are the sales for store Five?");
		
		storeFive = scnr.nextInt();
		
		while() {
			System.out.print("*");
		}
		
		
	}

}
