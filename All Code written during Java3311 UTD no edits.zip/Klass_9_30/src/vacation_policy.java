import java.util.*;
public class vacation_policy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		int userResponse;
		int numOfDays;
		
		System.out.println("How many years have you worked?");
		userResponse = scnr.nextInt();
		
		if( userResponse < 3 ) {
			System.out.println("14 days of vacation");
		}
		else if(userResponse <= 6){
			numOfDays = 21 +((userResponse-3)*2);
			System.out.println(numOfDays+" day of vacation");
			}
			else if(userResponse > 6) {
			numOfDays = 21+6+(userResponse-6);
			System.out.println(numOfDays+" days of vacation");
			}
		
	}

}
