import java.util.*;
public class GoingInLoops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		int userInput;
		
		
		System.out.println("Enter an ineger between 11 and 100");
		
		

	}

}
