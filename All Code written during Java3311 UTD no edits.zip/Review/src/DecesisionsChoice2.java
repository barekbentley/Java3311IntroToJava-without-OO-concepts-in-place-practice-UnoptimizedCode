import java.util.*;
public class DecesisionsChoice2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		
		int numShirts;
		
		System.out.println("How many shirts would you like to order?");
		numShirts = scnr.nextInt();
		
		if(numShirts<100) {
			System.out.println("That number is not avaliable, order more than 100");
		}
		else if(numShirts>=100 && numShirts <=499) {
			System.out.println("$4.99 per piece.");
		
		}else if(numShirts>=500 && numShirts <=999) {
		
			System.out.println("$3.99 per piece." );
		}else if(numShirts>= 1000 && numShirts <=2499) {
			System.out.println("$2.99 per piece." );
			
		}else if( numShirts>=2500 && numShirts<=4999) {
		System.out.println("$2.49 per piece." );
	
	}else if(numShirts>=5000) {
		
		System.out.println("$1.99 per piece.");
		
	};
	
	}
		
	}



	
	

