import java.util.*;

public class Sequential {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		double firstClass; double secondClass; double regularClass;
		double TAX = .0825;
		
		System.out.println("How many first class tickets sold?");
		
		firstClass = scnr.nextInt();
		
		System.out.println("How many second class tickets sold?");
		
		secondClass = scnr.nextInt();
		
		System.out.println("How many regular tickets sold?");
		
		regularClass = scnr.nextInt();
		
		double totalRevenue;
		
		double revenue = ((firstClass*50) + (secondClass*30)+(regularClass*20));
		
		totalRevenue = ((firstClass*50) + (secondClass*30)+(regularClass*20)+(revenue*TAX));
		
		System.out.println("Your total revenue is: "+totalRevenue);
		
		
		
	}

}
