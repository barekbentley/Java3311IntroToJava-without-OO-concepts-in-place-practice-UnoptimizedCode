import java.util.*;

public class phorLoopChoice2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
							
		int dayNumber = 0;
		
		int numPennies = 0;
		System.out.println("How many days have you worked?");
		int i = scnr.nextInt(); // i is how many days worked in which the user enters
		for(;i>0; i--) {
			//System.out.println("Hello");
			
			dayNumber++;
			
			if(numPennies==0) { //execption to add one penny the first day
				numPennies =+1;
				
			};
			
			if(numPennies==1) {
				System.out.println("Salary for day 1 : 1 penny");
			};
			if(numPennies>=2) {
				System.out.println("Salary for day "+dayNumber+" : "+numPennies+" pennies");
			}
			
			
			 
			
			numPennies = numPennies*2; //doubles the number of pennies the rest of the days
			
		};
		if(dayNumber ==0) {
			System.out.println("Cannot enter 0 days worked"); // when user enters 0 days worked.
			
		 
		}else {
		double totalPay = (numPennies*.01)-.01;
		System.out.println("Total Pay for " + dayNumber + " days $"+totalPay);
		}
	}
}

