	import java.util.*;
public class ReviewWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		int userInput;
		int product = 0;
		System.out.println("Enter a number between 1 and 100");
		
		userInput = scnr.nextInt();
		
		if(userInput < 100 && userInput>0 ) {
			product = userInput*10;
			System.out.println(product);
			while( product < 1000) {
				
				product = product *10;
				System.out.println(product);
				
		}
		}
		else {
		System.out.println("Input is less than 1 or greater than 100");
		
		}
		}
		
	}


