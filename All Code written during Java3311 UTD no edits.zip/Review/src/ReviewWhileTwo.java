import java.util.*;
public class ReviewWhileTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		int userInput = 0;
		
		int numOfKids=0; //stores number of kids
		//int countNumOfKids=0; // increases number of kids
		//int revFromKids =0; // stores revenue from kids
		
		int numOfStudents=0; //stores number of students
		//int countNumOfStudents=0; //increases number of students
		int revFromStudents =0;
		
		int numOfAdults = 0; // stores number of adults
	//	int countNumOfAdults = 0; //increases number of adults
		int revFromAdults = 0; 
		
		int numOfSeniors = 0; // stores number of Seniors
		//int countOfSeniors = 0; // stores number of Seniors
		int revFromSeniors =0;
		
		int totalNumberOfPatrons =0; // stores number of all guests served
		int totalRevenue =0; //Stores all revenue for the day
		
		
		System.out.println("Follow the prompts and enter integer values. To quit program enter -1");
		System.out.println();
		
		System.out.println("Enter the patrons age or enter -1 to quit");
		userInput = scnr.nextInt();
		while(userInput != -1) {
			if(userInput <= 4) {
				//revkids, totalkids, countkids,
			//System.out.println("Do kid stuff");
				numOfKids++;
				
			
			System.out.println("Enter the patrons age or press -1 to quit");
			userInput = scnr.nextInt();
			}
			else if(userInput <= 18) {
				// revstudents, totalstudents, countstudents
				//System.out.println("Do student stuff");
				numOfStudents++;
				
				System.out.println("Enter the patrons age or press -1 to quit");
				userInput = scnr.nextInt();
				
			}
			else if(userInput <= 64){
				//revsadults, total adults, countadults
			//System.out.println("Do adult stuff");
			numOfAdults++;
			System.out.println("Enter the patrons age or press -1 to quit");
			userInput = scnr.nextInt();
			}
			
			else {
			//System.out.println("Do senior stuff");
			numOfSeniors++;
			System.out.println("Enter the patrons age or press -1 to quit");
			userInput = scnr.nextInt();
			}
			
		//no kids revenue
		revFromStudents = numOfStudents *5; //revenue for students
		revFromAdults = numOfAdults *20;	//revenue for adults
		revFromSeniors = numOfSeniors *10;	//revenue for seniors
		totalRevenue = 	revFromStudents+revFromAdults+revFromSeniors;
		totalNumberOfPatrons = numOfKids+numOfStudents+numOfAdults+numOfSeniors;
				
		
			
		}
		
		//Print totals
		System.out.println("Perot Museum Today's Revenue");
		System.out.println("Printed totals");
		System.out.println("Total Number of kids: "+ numOfKids);
		System.out.println("Total Revenue from kids: $ 0 ");
		System.out.println("Total Number of students: "+numOfStudents);
		System.out.println("Total Revenue from students: $ "+revFromStudents);
		System.out.println("Total Number of Adults: "+numOfAdults);
		System.out.println("Total Revenue from Adults: $ "+revFromAdults);
		System.out.println("Total Number of Seniors: "+numOfSeniors);
		System.out.println("Total Revenue from Seniors: $ "+revFromSeniors);
		
		System.out.println("Total Revenue for today: $  "+totalRevenue);
		System.out.println("Total # of Patrons today:  "+totalNumberOfPatrons);
	}
	
}