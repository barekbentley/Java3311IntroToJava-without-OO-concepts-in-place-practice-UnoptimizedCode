import java.util.Scanner;
public class Example08_26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int hoursWorked = 40;
		double payPerHour = 50;
		double salary = hoursWorked*payPerHour;
		
		System.out.print(salary);
	}
	{	
		
		Scanner scnr; //variable declariation
		scnr = new Scanner(System.in); // variable initiliazatoin 
		
		int hoursWorked;
		double payPerHour;
		double salary;
		
		System.out.println("Enter Hours Worked");
		
		scnr.close();
	
	
	
	}
}


