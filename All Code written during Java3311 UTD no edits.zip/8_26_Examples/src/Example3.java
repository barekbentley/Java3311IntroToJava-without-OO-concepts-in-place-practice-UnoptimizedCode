import java.util.*;
public class Example3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*rase to greet the user: �Welcome to the Java programming class.�
Things to do :
Prompt the user as to what kind of info is expected
Get user name from keyboard
Print the greeting - Use System.out.println() to print the info

Sample input: 
Please enter your user name: John Doe
Sample output:
John Doe, Welcome to the Java programming class.
*/
		Scanner scnr = new Scanner(System.in);
		
		String userName;
		
		System.out.print("Please enter your name");
		
		userName = scnr.nextLine();
		
		
		System.out.println(userName + ", Welcome to Java programming class!");
		
		
	}

}
