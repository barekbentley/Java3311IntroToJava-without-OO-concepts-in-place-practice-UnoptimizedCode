import java.util.Scanner;

public class Example2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		{	
			
			Scanner scnr; //variable declariation
			scnr = new Scanner(System.in); // variable initiliazatoin 
			
			int hoursWorked;
			double payPerHour;
			double salary;
			
			
			System.out.println("Enter Hours Worked");
			hoursWorked = scnr.nextInt();
			
			System.out.println("Enter your Pay per Hour");
			
			payPerHour = scnr.nextDouble();
			
			salary = payPerHour * hoursWorked;
			
			System.out.println("Your pay is " + salary );
			scnr.close();
			
		
		
		
		}
	}
	}


