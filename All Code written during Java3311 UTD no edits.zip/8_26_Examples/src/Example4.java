import java.util.*;
public class Example4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Given cost of one water bottle as 0.99, get number of bottles of water being purchased, 
		 * calculate the total (do not worry about tax) & print the cost
		 */
		Scanner scnr = new Scanner(System.in);
		double waterBottlePrice = .99;
		int numBottles;
		double total;
		
		//prompt
		System.out.println("Enter # of water bottles purchased : ");
		numBottles = scnr.nextInt();
		total = numBottles * waterBottlePrice;
		System.out.println("Your total : $" +total);
	}

}
