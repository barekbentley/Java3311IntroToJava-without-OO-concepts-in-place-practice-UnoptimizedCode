
public class SortAnArrayMethod {

	static int[] testArray = {2,4,6,8,10,11};
	
	public static void sortMethod(int[] methodData) {
		for(int i =methodData.length-1; i>0; i--) {
			
		System.out.print(" "+methodData[i]);
		}
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sortMethod(testArray);
		
	}

}
