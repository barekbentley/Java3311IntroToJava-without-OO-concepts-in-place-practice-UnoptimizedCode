import java.util.Scanner;
public class klass_9_23_19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		double area;
		int userInput;
		double radius;
		double PI = 3.14;
		double length;
		double width;
		double base;
		double height;
		
		System.out.println(" Enter 1 for circle area, enter 2 for rectanlge area, enter 3 for triangle area, enter 4 to quit program");
		userInput = scnr.nextInt();					//take input
		switch (userInput) {
		
		case 1: 
			System.out.println("What is the radius?");
			radius = scnr.nextDouble();
			area = PI*radius*radius;
					System.out.println("The area of the circle is: "+area);
					//take input
					//calc area
					//print output
			break;
			
		case 2:
			System.out.println("What is the length? ");
			length = scnr.nextDouble();
			System.out.println("What is the width? ");
			width = scnr.nextDouble();
			area = length*width;
			System.out.println("The area of the rectangle is: "+area );
			
		break;
		
		case 3:
		System.out.println("What is the base? ");
		base = scnr.nextDouble();
		System.out.println("What is the height? ");
		height = scnr.nextDouble();
		area = (base*height)/2;
		System.out.println("The area of the triangle is: "+area );
		break;
		
		case 4:
			System.out.println("Have a good day!");
		}
		
		
		}
	}


