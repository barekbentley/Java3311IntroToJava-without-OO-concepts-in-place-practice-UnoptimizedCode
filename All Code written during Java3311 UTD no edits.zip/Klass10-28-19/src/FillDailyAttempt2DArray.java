
public class FillDailyAttempt2DArray {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double [][] dailyTemp = new double [12][31];
		
		for( int i=0; i<dailyTemp.length; ++i){ //
			for( int j =0; j<dailyTemp[i].length; ++j){
				dailyTemp[i][j] =-1;
			
			}
		}
		for( int i=0; i<dailyTemp.length; ++i){ //
			for( int j =0; j<dailyTemp[i].length; ++j){
				System.out.print(dailyTemp[i][j] + "");
			
			}
		System.out.println("");
		
		
	}

	}
}