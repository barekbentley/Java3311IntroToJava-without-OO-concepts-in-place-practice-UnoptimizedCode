
public class Example3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] colFill = new int [3][4];
		
		for(int i =0; i<colFill.length ; i++) { //FILL CODE
			for(int j =0; j< colFill[i].length ; j++ ) {
				colFill[i][j]=j;
			}
		}
			for( int i =0; i<colFill.length ; i++) {      //OUTPUT CODE
				for(int j =0; j < colFill[i].length; j++ ) {
					System.out.print(colFill[i][j] + "");
				}
				System.out.println("");
			}
	}
}
	


