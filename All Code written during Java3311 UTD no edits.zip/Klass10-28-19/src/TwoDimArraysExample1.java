
public class TwoDimArraysExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int ROWS =4, COLS =3; //constants
		
		int [][] exams = new int [ROWS][COLS];
		int [][] ae = new int [COLS] [ROWS]; //another exam
		//String [][] studentId = {"aa1"};
		String [][] test= {{"bsb84", "78"},{"92fgb", "asdf97"} };
		
		
	}

}
