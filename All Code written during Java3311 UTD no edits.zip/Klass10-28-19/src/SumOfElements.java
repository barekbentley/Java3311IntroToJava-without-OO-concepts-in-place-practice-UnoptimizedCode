
public class SumOfElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[][] rowFill = new int [3][4];
		
		for(int i =0; i<rowFill.length ; i++) { //FILL CODE
			for(int j =0; j< rowFill[i].length ; j++ ) {
				rowFill[i][j]=i;
			}
		}
			for( int i =0; i<rowFill.length ; i++) {      //OUTPUT CODE
				for(int j =0; j < rowFill[i].length; j++ ) {
					System.out.print(rowFill[i][j] + "");
				}
				System.out.println("");
			}
			System.out.println("");
			System.out.println("Sum of Rows");
	
	
	for(int i =0; i<rowFill.length ; i++) { //change to make 
		for(int j =0; j< rowFill[i].length ; j++ ) {
			rowFill[i][j]=i;
}
	
	}
	}

}