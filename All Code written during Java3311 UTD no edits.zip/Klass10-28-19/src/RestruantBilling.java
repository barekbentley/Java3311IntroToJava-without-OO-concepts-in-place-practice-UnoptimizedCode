import java.util.*;
public class RestruantBilling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ask user to enter the code or n to exit.
		//as long as user has not entered n : 
		//	identify the code and 
		//	get the corresponding price to your total & 
		//	ask user to enter the code/n again
		//whenever user entered n, present the bill which 
		//	lists all the items that were purchased along with it's price
		//	and final total
		
		Scanner scnr = new Scanner(System.in);
		
		String [] code = {"a1", "a2", "e1", "e2", "b1", "b2", "d1", "d2"};
		String[] name = {"fries", "onion rings", "Chicken marsala", "Veg Lasagna", "Bloody Mary",  "Peach Melba", "Tiramasu", "Cannoli"};
		double[] price = {.99, 1.99, 11.99, 10.99, 3.99, 3.50, 4.99, 4.50};
	
	do {
		//Prompt
		//System.out.println("Press any charace")
		//System.out.println("Enter the item Code");
		//String test = scnr.next();
	
	}while(userInput.equals("n"));
				//
		
		//String userInput = "Quick barown fox jumped over lazy dog";
		//String [] words = userInput.split("o");
		
		//for(int i=0; i<words.length; i++) {
			//System.out.print(words[i]);
		//}
	
	
	}
}



