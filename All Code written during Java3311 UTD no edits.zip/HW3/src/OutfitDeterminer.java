import java.util.*;
public class OutfitDeterminer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//setup variables and scanner
		Scanner scnr = new Scanner(System.in);
		int curTemp;
		//Prompt User
		System.out.println("What is today's Temperature?");
		
		curTemp = scnr.nextInt();
		
		//If else sequence to advise user what to where
		
		if (curTemp <= 40) {
			System.out.println("Grab a coat, winter hat & gloves");
		}
		else if(curTemp <= 65) {
			System.out.println("Get a light jacket");
		}
		else if(curTemp <=75) {
			System.out.println("Long sleeve outfit should be good");
		}
		else {
			System.out.println("put on sunscreen & wear a summer hat");
		}
	}

}
