
import java.util.Scanner;
public class HW2 {
	   public static void main (String [] args) {
		      Scanner scnr = new Scanner(System.in);
		      String firstName;
		      String lastName;
		      
		      firstName = scnr.next();
		      lastName = scnr.next();

		      System.out.println(firstName + ","+ " " + lastName);
		      
		      /* Your solution goes here  */

   }
}