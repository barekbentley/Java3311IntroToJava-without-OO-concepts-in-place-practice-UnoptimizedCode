
import java.util.*; // allows me to import the scanner
public class turnInHW2_9_1_19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scnr = new Scanner(System.in); // allows for keyboard input
		
		String nameEstablishment;
		int subTotal;
		double gratRate;
		double totGratuity;
		double totPrice;
		final String THX = "Thank you for choosing ";
		
		//Prompts for user input
		System.out.println("Enter the name of your establishment?");
		nameEstablishment = scnr.nextLine();
		
		System.out.println("Enter the subtotal :");
		subTotal = scnr.nextInt();
		
		System.out.println("Enter the Gratuity Rate :");
		gratRate = scnr.nextDouble();
		
		//Calculations and setting variable values
		
		totGratuity = subTotal * (gratRate/100);
		totPrice = subTotal + totGratuity;
		
		//Printing out Solution
		System.out.println(nameEstablishment);
		System.out.println();
		System.out.println("Sub total : " + "$" + subTotal);
		System.out.println();
		System.out.println("Gratuity : " + "$" + totGratuity);
		System.out.println();
		System.out.println("Total : " + "$" + totPrice);
		System.out.println();
		System.out.println(THX + nameEstablishment + "!");
		
		//Testing output
		//System.out.println(nameEstablishment);
		//System.out.println(subTotal);
		//System.out.println(gratRate);
		//System.out.println(totGratuity);
		//System.out.println(totPrice);
	}

}
