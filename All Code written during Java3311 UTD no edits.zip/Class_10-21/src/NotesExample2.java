import java.util.*;

public class NotesExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		
		String [] produce = {"apple", "orange", "grapes","banana"};
		double[] price = {1.99, 1.50, 3.99, 0.56};
		double [] cost = new double[produce.length];
		//Create an array capable of storing weight for elements in produce array.
		//Make a for loop that runs through each item in produce :
			//Prompt user to enter the weight of each item in the array produce 
			//Store the user's input into the weight array in the corresponding place.
		//Make a for loop that runs through each item in produce :
			//Calculate the cost of each purchase, 
			//Keep a running total of the the costs 
		//Print the final price (food item - so no tax calculation)
		
		double[] weightsProduce = new double[produce.length];
		
		for( int i =0; i<produce.length; ++i) {
			System.out.println("Enter the weight of produce item: "+produce[i]);
			weightsProduce[i] = scnr.nextDouble();
			
		}
		for( int i =0; i<produce.length; ++i) {
			cost[i] = weightsProduce[i]*price[i];
		}
		for ( int i =0; i<produce.length; ++i) {
			System.out.println("Cost of "+produce[i]+ " is " +cost[i]);
		}
		
		
	}

}
