
public class NotesExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		//each aspect of an item is stored in a different array.
		//Index of any object is same over all the arrays
		int[] studentId = {1, 3, 6, 10, 2};
		String[] studentName = {"A", "B", "C", "D", "E"};
		String[] studentMajor = {"ITSS","BUAN","ITSS","HR", "CS"};
		
		
		for( int i=0; i<studentId.length; ++i) {
			if(studentMajor[i].contentEquals("ITSS") ) {
			System.out.println(studentName[i]+" has ID "+studentId[i]+" and a mjor is "+studentMajor[i]);
			}
		}
		
	}

}
