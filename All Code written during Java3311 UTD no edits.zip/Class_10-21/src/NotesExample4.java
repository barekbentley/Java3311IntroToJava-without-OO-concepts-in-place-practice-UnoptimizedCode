import java.util.*;

public class NotesExample4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		String userInput;
		String[] code = {"a1", "a2", "e1", "e2", "b1", "b2", "d1", "d2"};
		String[] name = {"fries", "onion rings", "Chicken marsala", "Veg Lasagna", "Bloody Mary",  "Peach Melba", "Tiramasu", "Cannoli"};
		double[] price = {.99, 1.99, 11.99, 10.99, 3.99, 3.50, 4.99, 4.50};

		//ask user to enter the code or n to exit.
		//as long as user has not entered n : 
			//identify the code and 
			//get the corresponding price to your total & 
			//ask user to enter the code/n again
		//whenever user entered n, present the bill which 
			//lists all the items that were purchased along with it's price
			//and final total
			
		System.out.println("Enter the Code or press n to exit");
		userInput = scnr.next();
		while(!userInput.contentEquals("n")) {
			
			
		}
		
	
	
	
	
	
	
	
	}
	

}
