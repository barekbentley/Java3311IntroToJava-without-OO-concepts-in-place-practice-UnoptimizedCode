
public class QUIZ2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] studentID = {1,3,6,10,2}; //#1

		double[] doublesArray = new double[10]; //#2

		String [] stringArray = new String[20];  //#3

		System.out.println(doublesArray[7]);  //#4

		int [] numbers = new int[5]; //#5

		                                             
			for(int i = 0; i<5; i++) {             //#6
				numbers[i] = i;
				//System.out.println(number[0])
			}
			
			//#7
			numbers[1] = 1;
			
			//#8
			for( int i =0; i<5; i++) {
			
			System.out.println(numbers[i]);
			
			}

	}

}
