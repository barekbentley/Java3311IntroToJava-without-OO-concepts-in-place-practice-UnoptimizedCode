import java.util.*;
import java.text.DecimalFormat; //So I can edit how many decimals are shown in the final number
//Write a program that asks user to enter an item�s wholesale cost and it�s markup percentage. It should display the item�s retail price as the result. 

//For .e.g:

//If the wholesale cost is 5.00 and markup is 100%, then the retail price will be 10.00
//If the wholesale cost is 5.00 and markup is 50%, then the retail price will be 7.50
 
//Write a method called computeRetailPrice that takes in wholesale cost as well as markup% as inputs arguments and returns the retail price.



//In the main method

//get the values for the 2 variables from the user.
//Call the method computeRetailPrice with the values given by the user.
//Print the result given by the method computeRetailPrice.


public class MarkupMethod {

	public static double computeRetailPrice(double wholeSalePrice , double markupPerc ) {
		double totalPrice = (wholeSalePrice+(wholeSalePrice*markupPerc/100));
		return totalPrice;
	}




	public static void main(String[] args) {

		
		
		// TODO Auto-generated method stub
			DecimalFormat df = new DecimalFormat("#,###,##0.00"); //formats two decimal places
			Scanner scnr = new Scanner(System.in);
			double wSale;
			double uPrice;
		System.out.println("Enter the whole sale price");
			wSale = scnr.nextDouble();
		System.out.println("Enter the markup %, just the number");		
			uPrice = scnr.nextDouble();
		System.out.println("The total price is: $"+df.format(computeRetailPrice(wSale,uPrice)) );
		
	}

}

