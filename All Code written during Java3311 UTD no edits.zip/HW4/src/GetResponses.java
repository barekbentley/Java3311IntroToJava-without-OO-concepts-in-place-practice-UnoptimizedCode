import java.util.Scanner;
public class GetResponses {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		int numKids = 0;    //holds # of kids
		int numKidsCounter = 0; //counts for kids # input
		int numAdultsCounter =0; // counts # of adults for input
		int numAdults=0; //holds # of adults
		int numTotal =0; // holds numKids and numAdults
		int i = 0;   // increases for the loop
		
		int j = 1; //counts up the number of family's
		while (i<5) {
			System.out.println("Enter # of adults for family "+j);
			numAdultsCounter = scnr.nextInt();
			System.out.println("Enter # of kids for family "+j);
			numKidsCounter = scnr.nextInt();
			
			numKids= numKids + numKidsCounter;
			numAdults= numAdults + numAdultsCounter;
			
			i++;
			j++;
			
		}
		numTotal= numKids + numAdults;
		System.out.println("Total # of adults: "+numAdults);
		System.out.println();
		System.out.println("Total # of kids: "+numKids);
		System.out.println();
		System.out.println("Overall headcount: " +numTotal);
		

				
	}
	

	}


