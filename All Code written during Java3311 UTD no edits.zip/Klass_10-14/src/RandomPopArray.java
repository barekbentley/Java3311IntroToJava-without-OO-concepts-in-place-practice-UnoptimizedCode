
public class RandomPopArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] randomInt = new int[10];
		for (int i = 0; i < randomInt.length; i++) {
		  randomInt[i] = (int) (Math.random() * 100);
	}

}
}