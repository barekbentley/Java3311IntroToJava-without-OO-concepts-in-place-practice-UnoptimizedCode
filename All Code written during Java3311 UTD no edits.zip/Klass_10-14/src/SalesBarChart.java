import java.util.*;
public class SalesBarChart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		final int STORE_NUMBER = 5;
		int[] userSales = new int[STORE_NUMBER];

		//loop for input and array creation and input validation
		for (int i =0; i < STORE_NUMBER; i++) {
		do {
			System.out.println("Enter the number of Sales for #"+ (i+1));
			userSales[i] = scnr.nextInt();
		}while(userSales[i]<0);
		}
		//print bar  chart off the data in the created array
		int numOfLoopsForStars;
		
		for ( int i =0; i < STORE_NUMBER; i++) {
		
			numOfLoopsForStars = userSales[i]/100;
			
			System.out.println();
			int j=0;
			do {
			System.out.print("*");
			j++;
		}while(numOfLoopsForStars>j);
		}
	}
}	
		
	


