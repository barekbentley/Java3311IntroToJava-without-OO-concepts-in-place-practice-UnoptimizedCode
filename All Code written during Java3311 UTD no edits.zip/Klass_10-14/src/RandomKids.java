import java.util.*;
public class RandomKids {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		final int NUMBER_OF_HOUSES = 10;
		int[] inputKidsStore = new int[NUMBER_OF_HOUSES];
		int inputKids;
		int numSingleFam;
		
		
		int familyResponse;
		for(int forLoop_i=0; forLoop_i<10; forLoop_i++ ) {
		System.out.println("Are you a single child household?, if so, type 1 if no type 2");
		
		familyResponse = scnr.nextInt();
		
		if(familyResonse == 1) {
		// logic for single child household
		}
		else {
		//logic for multiple child
		}
		
		
		
		//if()
		
		
		
		
		
		
		//do {
		
			//System.out.println("How many kids in your house?"); //attempting for input validation
		//inputKids = scnr.nextInt();
		
	//}while(inputKids <0 && inputKidsStore );

}
}