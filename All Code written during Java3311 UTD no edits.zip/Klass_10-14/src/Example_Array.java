
public class Example_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] travel = {"Italy", "Spain", "Japan", "Korea"};
		
		int i;
		
		for (i=0; i < travel.length; i++) {
		System.out.println(travel[i]);
		}
		
		travel[0] = "Jamica";
		travel[1] = "Costa Rica";
		travel[2] = "Mexico";
		System.out.println("Change of Plans------------------");
		
		for (i=0; i < travel.length; i++) {
			System.out.println(travel[i]);
		
	}
	}
}

