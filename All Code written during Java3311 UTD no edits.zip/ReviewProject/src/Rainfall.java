import java.util.*;

public class Rainfall {

	
	static String[] months = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
	static double[] monthTotals = new double[12];
	double avgRain;
	static double totalRain;
	static double rainMax;
	static double rainMin;
	
	
	public static void get_inputs() {
	Scanner scnr = new Scanner(System.in);
	
	for(int i=0; i<months.length; i++) {
		System.out.println("Enter the amount of rainfall for month of "+ months[i]);
		monthTotals[i]= scnr.nextDouble();
	}
	return;
	}
	public static void totalRain() {
		totalRain = monthTotals[0]+monthTotals[1]+monthTotals[2]+monthTotals[3]+monthTotals[4]+monthTotals[5]+monthTotals[6]+monthTotals[7]+monthTotals[8]+monthTotals[9]+monthTotals[10]+monthTotals[11];
		System.out.println("The total rain amount is: ");
		System.out.println(totalRain);
		return;
	}
	public static void avgRain() {
		System.out.println("The average amount of rain is: ");
		System.out.println(totalRain/12);
		return;
	}
	public static void rainMax() {
		
		double rainMaxMethodVar=0;
		double buffer =0;
		String j="test";//counter for months call
		for(int i=0; i<months.length;i++) {
			//System.out.println(monthTotals[i]); // loop does run 12 times
			
			if(monthTotals[i]>buffer) {
				buffer = monthTotals[i];
				rainMaxMethodVar = buffer;
				j = months[i];
			}
		
			
		}
		
		System.out.println("The max is: "+rainMaxMethodVar+" For the month of "+j);		
		return;
	}
	
	public static void rainMin() {
		double rainMinMethodVar=0;
		double buffer =900000000;
		String p="test";
		for(int i=0; i<months.length;i++) {
			//System.out.println(monthTotals[i]); // loop does run 12 times
			
			if(monthTotals[i]<buffer) {
				buffer = monthTotals[i];
				rainMinMethodVar = buffer;
				p=months[i];
			}
			
	
		}
		System.out.println("The min is: "+rainMinMethodVar+" For the month of "+p);		
		return;
	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			get_inputs();
			totalRain();
			avgRain();
			rainMax();
			rainMin();
	}

	}
	
