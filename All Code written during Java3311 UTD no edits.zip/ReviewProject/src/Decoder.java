import java.util.*;

public class Decoder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] alphabet = new String[] {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}; //don't think I need this anymore
		char[] alphabet2 = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',' '};
		String userInput; 
		Scanner scnr = new Scanner(System.in); //takes input
		
		System.out.println("Enter your sequence of numbers each following with a space, including the last"); //promts user
		
		userInput = scnr.nextLine(); //gets user input and takes spaces
		//System.out.println(userInput + " is user input"); //testing code
		
	//System.out.println(userInput.length()+" Length of userinput"); //testing code
	
	char[] userInputArrayChar = new char [userInput.length()]; // critical piece defines the size of char array I will create
	
	 
	//System.out.println(userInputArrayChar.length + " user input array length"); //testing code
	
	//Creates a char array from the user input string
	for(int i=0; i<userInputArrayChar.length;i++) {	
		userInputArrayChar[i] = userInput.charAt(i); //{0, ,0, ,0 ,}
		
		}
	// adds space at the end of userInputArrayChar
	//userInputArrayChar[userInputArrayChar.length-1] = ' ';
	
	
	int indexOfIntArray =0; //counter for the times I need to move up in the new int array
	int[] filterNumNoSpaces = new int [userInputArrayChar.length*2]; //shrinks the size to include
	
	
	for(int j=0; j<userInputArrayChar.length-1; j++) { //subtract one to avoid oob error
		//System.out.print(userInputArrayChar[j]); 
		
		//for single ints
		if(userInputArrayChar[j] != ' ' && userInputArrayChar[j+1] == ' ' ) {
			char holder = userInputArrayChar[j];
			int holder2 = Integer.parseInt(String.valueOf(holder));
			
			filterNumNoSpaces[indexOfIntArray] = holder2; 
			indexOfIntArray++;
		
		}
		
		//for ints with two numbers
		else if(userInputArrayChar[j] != ' ' && userInputArrayChar[j+1] != ' ' ) {
			char holder = userInputArrayChar[j]; 
			char holderAdded = userInputArrayChar[j+1];
			
			String holderAddedString = new StringBuilder().append(holder).append(holderAdded).toString();
			int holder2 = Integer.parseInt(String.valueOf(holderAddedString));
			
			filterNumNoSpaces[indexOfIntArray] = holder2; 
			indexOfIntArray++;
			j+=2; //needed to skip ahead so that two integer ints are saved accordingly
		}
		
		
	}
	filterNumNoSpaces[indexOfIntArray+1]=-1;	//acts as place to wihtin the decipherer	
		
	//NOW TO BUILD A DECIPHER loop or something
	int i =0;
	do {
		//System.out.println("number of inputs");//testing
		if(filterNumNoSpaces[i] == 0) {
			System.out.print("a");
		}
		if(filterNumNoSpaces[i] == 1) {
			System.out.print("b");
		}
		if(filterNumNoSpaces[i] == 2) {
			System.out.print("c");
		}
		if(filterNumNoSpaces[i] == 3) {
			System.out.print("d");
		}
		if(filterNumNoSpaces[i] == 4) {
			System.out.print("e");
		}
		if(filterNumNoSpaces[i] == 5) {
			System.out.print("f");
		}
		if(filterNumNoSpaces[i] == 6) {
			System.out.print("g");
		}
		if(filterNumNoSpaces[i] == 7) {
			System.out.print("h");
		}
		if(filterNumNoSpaces[i] == 8) {
			System.out.print("i");
		}
		if(filterNumNoSpaces[i] == 9) {
			System.out.print("j");
		}
		if(filterNumNoSpaces[i] == 10) {
			System.out.print("k");
		}
		if(filterNumNoSpaces[i] == 11) {
			System.out.print("l");
		}
		if(filterNumNoSpaces[i] == 12) {
			System.out.print(",");
		}
		if(filterNumNoSpaces[i] == 13) {
			System.out.print("n");
		}
		if(filterNumNoSpaces[i] == 14) {
			System.out.print("o");
		}
		if(filterNumNoSpaces[i] == 15) {
			System.out.print("p");
		}
		if(filterNumNoSpaces[i] == 16) {
			System.out.print("q");
		}
		if(filterNumNoSpaces[i] == 17) {
			System.out.print("r");
		}
		if(filterNumNoSpaces[i] == 18) {
			System.out.print("s");
		}
		if(filterNumNoSpaces[i] == 19) {
			System.out.print("t");
		}
		if(filterNumNoSpaces[i] == 20) {
			System.out.print("u");
		}
		if(filterNumNoSpaces[i] ==21 ) {
			System.out.print("v");
		}
		if(filterNumNoSpaces[i] == 22) {
			System.out.print("w");
		}
		if(filterNumNoSpaces[i] == 23) {
			System.out.print("x");
		}
		if(filterNumNoSpaces[i] == 24) {
			System.out.print("y");
		}
		if(filterNumNoSpaces[i] == 25) {
			System.out.print("z");
		}
		i++;
	}while(filterNumNoSpaces[i+1]!=-1);
	
}

	}

	
	
	