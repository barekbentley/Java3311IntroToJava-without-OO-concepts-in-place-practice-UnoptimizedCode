import java.util.Scanner;

public class curlyQs {

	public static void get_parens(String parensAll) {
	
		String leftParens = parensAll.replace("(", "");
		
		String rightParens = parensAll.replace(")", "");
	
		int rightParensCount = rightParens.length();
		
		int leftParensCount = leftParens.length();
		
		if(rightParensCount == leftParensCount ) {
			System.out.println(parensAll+" is balanced");
		}
		else {
			System.out.println(parensAll+" is not balanced");
			}

	
	return;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Enter the parenthesis string");
		String stringP = scnr.nextLine();
		
		get_parens(stringP);
		
	}

}
