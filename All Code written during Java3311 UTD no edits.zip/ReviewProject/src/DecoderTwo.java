import java.util.*;
public class DecoderTwo {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner scnr = new Scanner(System.in);
		char[] alphabet = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
		
		String userInput;
		//prompt
		int[] array = new int[100];
		int[] array2 = new int[100];
		System.out.println("Enter your numbers");
		
		String line1 = scnr.nextLine(); // Read 1st line
		String[] numbers1 = line1.split(" "); // Split based on space
		for(int i=0;i<numbers1.length;i++){
		    
			array[i] = Integer.parseInt(numbers1[i]);
		}

		String line2 = scnr.nextLine(); // Read 2nd line
		String[] numbers2 = line2.split(" "); // Split based on space
		for(int i=0;i<numbers2.length;i++){
		   
			array2[i] = Integer.parseInt(numbers2[i]);
		}
		
		
		
		
		
		
		
		
		
		
		//String userInputWithoutSpaces =userInput.replaceAll("\\s+", ",");
		
		//System.out.println(userInputWithoutSpaces); //testing
		//System.out.println(userInputWithoutSpaces.length());
		//System.out.println("")
		
		//int index =0;
		//int cursor =0;
		//int[] userInputStringCastToIntArray = new int[userInput.length()]; //ar[]
		
		//for(int i =0; i<userInputWithoutSpaces.length(); ++i) {   //build an array of user input casting the strings as int's //potentially change i to k in the loop 
			//if(userInputWithoutSpaces.charAt(i) == ',' ) {
				//String j = userInputWithoutSpaces.substring(cursor, i); //int a=Integer.parseInt(String.valueOf(c));
			//	userInputStringCastToIntArray[index] = Integer.parseInt(String.valueOf(j));
				//i++;
				//index++;
				//cursor =i;
				//}
		//System.out.println(userInputStringCastToIntArray[1]+userInputStringCastToIntArray[2]);
			//	String h = userInputWithoutSpaces.substring(cursor);
			//userInputStringCastToIntArray[index] = Integer.parseInt(String.valueOf(h));
				
			}
		           // userInputStringCastToIntArray[i] = 
		            
		}
	
	
	

