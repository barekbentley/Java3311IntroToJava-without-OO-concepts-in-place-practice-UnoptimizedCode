
public class Calendar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] calendar= new int[12][31];
		int i=0;
		int j = 0;
		int numDays[] = {31,28,31,30,31,30,31,31,30,31,30,31};
		String months[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

		for(int q =0; q<12; q++) { //This set of code fills my entire calendar array with -1's
			for(int p =0; p<31; p++) {
		calendar[q][p] = -1;
					//System.out.println("count"+q+"count"+p+calendar[q][p]);
					
	}
		}
		for(int m=0; m<months.length; ++m) {  //m to refer to String array of months
					//j++;
				System.out.println("\r");
					System.out.println(months[m]);
					//System.out.println(" ");
				//System.out.println("\r");// test code runs according to the correct number of months in the year array
					
			for(int d =0, t=1; d<numDays[m]; ++d) {//d to refer to int array of numDays
					calendar[m][d]=t;
					t++;
				//System.out.println (numDays[m]); //test code runs according to the correct number of days in the month in the monnth array
					//System.out.println();
					if(calendar[m][d]<=2) {    // up to 2 for spacing 
					System.out.print(calendar[m][d]+"  ");
					}
					if(calendar[m][d]<=7 && calendar[m][d] >2 ) {
						System.out.print(calendar[m][d]+"   ");
					}
					if(calendar[m][d] ==7) {
						System.out.print("\r");
					}
					if(calendar[m][d]<=14 && calendar[m][d] >7 ) {
						System.out.print(calendar[m][d]+"  ");
					}
					if(calendar[m][d] ==14) {
						System.out.print("\r");
					}
					if(calendar[m][d] <=16 && calendar[m][d] >14) { // up to 16 for spacing reasons
						System.out.print(calendar[m][d]+" "); 
					}
					if(calendar[m][d]<=21 && calendar[m][d] >16 ) {
						System.out.print(calendar[m][d]+"  ");
					}
					if(calendar[m][d] ==21) {
						System.out.print("\r");
					}
					if(calendar[m][d] <=23 && calendar[m][d] >21) { // up to 23 for spacing reasons
						System.out.print(calendar[m][d]+" ");
					}
					if(calendar[m][d]<=28 && calendar[m][d] >23 ) {
						System.out.print(calendar[m][d]+"  ");			
					}
					if(calendar[m][d] ==28) {
						System.out.print("\r");
					}
					if(calendar[m][d] <=31 && calendar[m][d] >28) { // up to 31 for spacing reasons
						System.out.print(calendar[m][d]+" ");
					}
					
					
						//else if(calendar[m][d]>7 && calendar[m][d] <8 ) {
					//System.out.println("\r");
					//}
					//else if (calendar[m][d]<=14)
						//System.out.print(calendar[m][d]+" ");
					
			}
		}
	}

}

	

