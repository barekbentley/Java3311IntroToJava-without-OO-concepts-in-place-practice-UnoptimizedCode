import java.util.*;

public class ArraysProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Write code to get 10 inputs from the user. (Make sure to declare an integer array of that size).

		//Employ a for loop that takes in the 10 user inputs and store them in the above said array.

		//The user inputs needs to be positive numbers (0 and above is valid)...

		//After user enters all the 10 values, employ another for loop to find

		//how many of those elements are odd numbers and
		//how many are even numbers.
		//Print the findings.


		
		
		Scanner scnr = new Scanner(System.in);
		
		final int USER_INPUT_ARRAY_SIZE = 10;
		int[] userInputArray = new int [USER_INPUT_ARRAY_SIZE];
		
		int i;
		int numberOfOdd =0;
		int numberOfEven=0;
		for ( i=0; i<USER_INPUT_ARRAY_SIZE; i++) {
		do {
			
				System.out.println("Enter 0 or a positive integer");
				
				userInputArray[i] = scnr.nextInt();
				if(userInputArray[i]<0) {
					System.out.println("That is not a positive integer or 0");
				}
				
			
		
		}while(userInputArray[i]<0); //data validation for positive numbers
		

		
		

				
				}
		for ( i=0; i<USER_INPUT_ARRAY_SIZE; i++) { 
			if( userInputArray[i] % 2 ==0 ) {
			numberOfEven = numberOfEven+1;
			
			}
			if( userInputArray[i] % 2 !=0 ) {
				numberOfOdd = numberOfOdd+1;
			}
		}
		System.out.println("Number of odd numbers: "+ numberOfOdd);
		System.out.println("Number of even numbers: "+ numberOfEven);
			}

}
	



